from django.urls import path

from . import views

urlpatterns = [
    path('hr_admin/benefits/', views.benefits_view, name='benefits'),
    path('hr_admin/hr_reports/', views.reports_view, name='hr_reports'),
    path('hr_admin/new_hire/', views.newhire_view, name='new_hire'),
    path('hr_admin/on_boarding/', views.onboarding_view, name='on_boarding'),
    path('hr_admin/payroll/', views.payroll_view, name='payroll'),
    path('hr_admin/terminations/', views.terminations_view, name='terminations'),
]