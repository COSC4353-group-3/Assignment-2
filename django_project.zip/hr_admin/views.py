from django.shortcuts import render


def benefits_view(request):
    return render(request, 'hr_admin/benefits.html', {'title': 'Benefits'})


def reports_view(request):
    return render(request, 'hr_admin/hr_reports.html', {'title': 'HR Reports'})


def newhire_view(request):
    return render(request, 'hr_admin/new_hire.html', {'title': 'New Hire'})


def onboarding_view(request):
    return render(request, 'hr_admin/on_boarding.html', {'title': 'On-Boarding'})


def payroll_view(request):
    return render(request, 'hr_admin/payroll.html', {'title': 'Payroll'})


def terminations_view(request):
    return render(request, 'hr_admin/terminations.html', {'title': 'Terminations'})