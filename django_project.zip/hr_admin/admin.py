from django.contrib import admin

from .models import HR
from django.utils.html import format_html


@admin.register(HR)
class HRAdmin(admin.ModelAdmin):
    list_display = ['title', 'show_website', ]

    def show_website(self, obj):
        return format_html("<a href='{url}'>Link</a>", url=obj.website)
    show_website.allow_tags = True
    show_website.short_description = 'Link'
