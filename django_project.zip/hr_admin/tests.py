from django.test import SimpleTestCase, Client
from django.urls import reverse, resolve
from hr_admin.views import *
# Create your tests here.


class Test_Engineering_URLS(SimpleTestCase):

    def test_benefits(self):
        url = reverse('benefits')
        self.assertEquals(resolve(url).func, benefits_view)

    def test_hr_reports(self):
        url = reverse('hr_reports')
        self.assertEquals(resolve(url).func, reports_view)

    def test_new_hire(self):
        url = reverse('new_hire')
        self.assertEquals(resolve(url).func, newhire_view)

    def test_on_boarding(self):
        url = reverse('on_boarding')
        self.assertEquals(resolve(url).func, onboarding_view)

    def test_payroll(self):
        url = reverse('payroll')
        self.assertEquals(resolve(url).func, payroll_view)

    def test_terminations(self):
        url = reverse('terminations')
        self.assertEquals(resolve(url).func, terminations_view)


class Test_HR_Views(SimpleTestCase):

    def setUp(self):
        self.client = Client()
        self.benefits_url = reverse('benefits')
        self.hr_reports_url = reverse('hr_reports')
        self.new_hire_url = reverse('new_hire')
        self.on_boarding_url = reverse('on_boarding')
        self.payroll_url = reverse('payroll')
        self.terminations_url = reverse('terminations')

    def test_benefits_GET(self):
        response = self.client.get(self.benefits_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'hr_admin/benefits.html')

    def test_hr_reports_GET(self):
        response = self.client.get(self.hr_reports_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'hr_admin/hr_reports.html')

    def test_new_hire_GET(self):
        response = self.client.get(self.new_hire_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'hr_admin/new_hire.html')

    def test_on_boarding_GET(self):
        response = self.client.get(self.on_boarding_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'hr_admin/on_boarding.html')

    def test_payroll_support_GET(self):
        response = self.client.get(self.payroll_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'hr_admin/payroll.html')

    def test_terminations_support_GET(self):
        response = self.client.get(self.terminations_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'hr_admin/terminations.html')
