from django.apps import AppConfig


class HrAdminConfig(AppConfig):
    name = 'hr_admin'
