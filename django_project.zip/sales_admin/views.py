from django.shortcuts import render


def demo_view(request):
    return render(request, 'sales_admin/sales_demo.html', {'title': 'Sales Demo'})


def leads_view(request):
    return render(request, 'sales_admin/sales_leads.html', {'title': 'Sales Leads'})


def reports_view(request):
    return render(request, 'sales_admin/sales_reports.html', {'title': 'Sales Reports'})
