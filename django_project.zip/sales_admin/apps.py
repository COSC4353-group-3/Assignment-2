from django.apps import AppConfig


class SalesAdminConfig(AppConfig):
    name = 'sales_admin'
