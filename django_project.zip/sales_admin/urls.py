from django.urls import path

from . import views

urlpatterns = [
    path('sales_admin/demo/', views.demo_view, name='demo'),
    path('sales_admin/leads/', views.leads_view, name='leads'),
    path('sales_admin/reports/', views.reports_view, name='sales_report'),
]
