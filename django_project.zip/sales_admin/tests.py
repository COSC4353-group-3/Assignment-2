from django.test import SimpleTestCase, Client
from django.urls import reverse, resolve
from sales_admin.views import *
# Create your tests here.


class TestSalesURLS(SimpleTestCase):

    def test_demo(self):
        url = reverse('demo')
        self.assertEquals(resolve(url).func, demo_view)

    def test_leads(self):
        url = reverse('leads')
        self.assertEquals(resolve(url).func, leads_view)

    def test_sales_report(self):
        url = reverse('sales_report')
        self.assertEquals(resolve(url).func, reports_view)


class Test_HR_Views(SimpleTestCase):

    def setUp(self):
        self.client = Client()

        self.demo_url = reverse('demo')
        self.leads_url = reverse('leads')
        self.sales_report_url = reverse('sales_report')

    def test_demos_GET(self):
        response = self.client.get(self.demo_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'sales_admin/sales_demo.html')

    def test_leads_GET(self):
        response = self.client.get(self.leads_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'sales_admin/sales_leads.html')

    def test_sales_report_GET(self):
        response = self.client.get(self.sales_report_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'sales_admin/sales_reports.html')
