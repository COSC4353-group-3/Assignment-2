from django.shortcuts import render


def app_admin_view(request):
    return render(request, 'engineering_admin/app_admin.html', {'title': 'App Admin'})


def app_development_view(request):
    return render(request, 'engineering_admin/app_development.html', {'title': 'App Development'})


def application_monitoring_view(request):
    return render(request, 'engineering_admin/application_monitoring.html', {'title': 'Application Monitoring'})


def release_management_view(request):
    return render(request, 'engineering_admin/release_management.html', {'title': 'Release Management'})


def tech_support_view(request):
    return render(request, 'engineering_admin/tech_support.html', {'title': 'Tech Support'})