from django.urls import path
from . import views

urlpatterns = [
    path('engineering_admin/app_admin/',
         views.app_admin_view, name='app_admin'),
    path('engineering_admin/app_development/',
         views.app_development_view, name='app_development'),
    path('engineering_admin/application_monitoring/',
         views.application_monitoring_view, name='application_monitoring'),
    path('engineering_admin/release_management/',
         views.release_management_view, name='release_management'),
    path('engineering_admin/tech_support/',
         views.tech_support_view, name='tech_support'),
]
