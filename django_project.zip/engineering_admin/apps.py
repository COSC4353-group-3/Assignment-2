from django.apps import AppConfig


class EngineeringAdminConfig(AppConfig):
    name = 'engineering_admin'
