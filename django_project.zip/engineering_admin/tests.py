from django.test import SimpleTestCase, Client
from django.urls import reverse, resolve
from engineering_admin.views import *
# Create your tests here.


class Test_Engineering_URLS(SimpleTestCase):

    def test_app_admin(self):
        url = reverse('app_admin')
        self.assertEquals(resolve(url).func, app_admin_view)

    def test_app_development(self):
        url = reverse('app_development')
        self.assertEquals(resolve(url).func, app_development_view)

    def test_application_monitoring(self):
        url = reverse('application_monitoring')
        self.assertEquals(resolve(url).func, application_monitoring_view)

    def test_release_management(self):
        url = reverse('release_management')
        self.assertEquals(resolve(url).func, release_management_view)

    def test_tech_support(self):
        url = reverse('tech_support')
        self.assertEquals(resolve(url).func, tech_support_view)


class Test_Engineering_Views(SimpleTestCase):

    def setUp(self):
        self.client = Client()
        self.app_admin_url = reverse('app_admin')
        self.app_dev_url = reverse('app_development')
        self.app_monitor_url = reverse('application_monitoring')
        self.release_management = reverse('release_management')
        self.tech_support_url = reverse('tech_support')


    def test_app_admin_GET(self):
        response = self.client.get(self.app_admin_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'engineering_admin/app_admin.html')

    def test_app_development_GET(self):
        response = self.client.get(self.app_dev_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'engineering_admin/app_development.html')

    def test_app_monitor_GET(self):
        response = self.client.get(self.app_monitor_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'engineering_admin/application_monitoring.html')

    def test_release_manage_GET(self):
        response = self.client.get(self.release_management)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'engineering_admin/release_management.html')

    def test_tech_support_GET(self):
        response = self.client.get(self.tech_support_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'engineering_admin/tech_support.html')
