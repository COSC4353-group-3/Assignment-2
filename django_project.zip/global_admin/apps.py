from django.apps import AppConfig


class GlobalAdminConfig(AppConfig):
    name = 'global_admin'
