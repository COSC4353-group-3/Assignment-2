from django.shortcuts import render


def assign_roles_view(request):
    return render(request, 'global_admin/assign_roles.html',
                  {'title': 'Assign Roles'})


def help_desk_view(request):
    return render(request, 'global_admin/help_desk.html',
                  {'title': 'Help Desk'})


def user_accounts_view(request):
    return render(request, 'global_admin/manage_user_accounts.html',
                  {'title': 'Manage User Accounts'})
