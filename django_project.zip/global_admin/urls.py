from django.urls import path

from . import views

urlpatterns = [
    path('global_admin/assign_roles/', views.assign_roles_view, name='assign_roles'),
    path('global_admin/help_desk/', views.help_desk_view, name='help_desk'),
    path('global_admin/user_accounts/', views.user_accounts_view, name='user_accounts'),
]
