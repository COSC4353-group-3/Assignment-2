import self as self
from django.test import SimpleTestCase, Client
from django.urls import reverse, resolve
from global_admin.views import *

# Create your tests here.


class Test_Global_URLS(SimpleTestCase):

    def test_assign_roles(self):
        url = reverse('assign_roles')
        self.assertEquals(resolve(url).func, assign_roles_view)

    def test_help_desk(self):
        url = reverse('help_desk')
        self.assertEquals(resolve(url).func, help_desk_view)

    def test_user_accounts(self):
        url = reverse('user_accounts')
        self.assertEquals(resolve(url).func, user_accounts_view)


class Test_Global_Views(SimpleTestCase):

    def setUp(self):
        self.client = Client()
        self.assign_roles_url = reverse('assign_roles')
        self.help_desk_url = reverse('help_desk')
        self.manage_user_accounts_url = reverse('user_accounts')

    def test_assign_roles_GET(self):
        response = self.client.get(self.assign_roles_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'global_admin/assign_roles.html')

    def test_help_desk_GET(self):
        response = self.client.get(self.help_desk_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'global_admin/help_desk.html')

    def test_manage_user_accounts_GET(self):
        response = self.client.get(self.manage_user_accounts_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'global_admin/manage_user_accounts.html')

