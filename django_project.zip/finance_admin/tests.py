import self as self
from django.test import SimpleTestCase, TestCase, Client
from django.urls import reverse, resolve
from finance_admin.views import *

# Create your tests here.


class Test_Finance_URLS(SimpleTestCase):

    def test_payable(self):
        url = reverse('payable')
        self.assertEquals(resolve(url).func, payable_view)

    def test_receivables(self):
        url = reverse('receivables')
        self.assertEquals(resolve(url).func, receivables_view)

    def test_reports(self):
        url = reverse('reports')
        self.assertEquals(resolve(url).func, reports_view)

    def test_tax(self):
        url = reverse('tax')
        self.assertEquals(resolve(url).func, tax_view)


class Test_Finance_Views(SimpleTestCase):

    def setUp(self):
        self.client = Client()
        self.app_payable_url = reverse('payable')
        self.app_receivables_url = reverse('receivables')
        self.app_reports_url = reverse('reports')
        self.tax_url = reverse('tax')

    def test_payable_GET(self):
        response = self.client.get(self.app_payable_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'finance_admin/accounts_payable.html')

    def test_receivables_GET(self):
        response = self.client.get(self.app_receivables_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'finance_admin/accounts_receivables.html')

    def test_reports_GET(self):
        response = self.client.get(self.app_reports_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'finance_admin/finance_reports.html')

    def test_tax_GET(self):
        response = self.client.get(self.tax_url)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'finance_admin/tax.html')
