from django.shortcuts import render


def payable_view(request):
    return render(request, 'finance_admin/accounts_payable.html', {'title': 'Accounts Payable'})


def receivables_view(request):
    return render(request, 'finance_admin/accounts_receivables.html', {'title': 'Accounts Receivables'})


def reports_view(request):
    return render(request, 'finance_admin/finance_reports.html', {'title': 'Finance Reports'})


def tax_view(request):
    return render(request, 'finance_admin/tax.html', {'title': 'Tax'})