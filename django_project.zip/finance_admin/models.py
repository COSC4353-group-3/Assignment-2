from django.db import models


class Finance(models.Model):
    title = models.CharField(max_length=100)
    website = models.URLField(max_length=250)

    def __str__(self):  # to make post descriptive by title
        return self.title

    class Meta:
        verbose_name_plural = "Finance"
