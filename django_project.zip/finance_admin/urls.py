from django.urls import path

from . import views

urlpatterns = [
    path('finance_admin/payable/', views.payable_view, name='payable'),
    path('finance_admin/receivables/', views.receivables_view, name='receivables'),
    path('finance_admin/reports/', views.reports_view, name='reports'),
    path('finance_admin/tax/', views.tax_view, name='tax'),
]