from django.apps import AppConfig


class FinanceAdminConfig(AppConfig):
    name = 'finance_admin'
